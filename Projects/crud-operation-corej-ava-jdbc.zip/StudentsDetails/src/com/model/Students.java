package com.model;

public class Students {

	private int id;
	private String fName;
	private String lName;
	private String department;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFname() {
		return fName;
	}

	public void setFname(String fname) {
		this.fName = fname;
	}

	public String getLname() {
		return lName;
	}

	public void setLname(String lname) {
		this.lName = lname;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	@Override
	public String toString() {
		return "Students [id=" + id + ", fName=" + fName + ", lName=" + lName + ", department=" + department + "]";
	}

}
