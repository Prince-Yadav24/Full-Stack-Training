package com.crud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.model.Students;

public class Resources {

	public static void main(String[] args) {

		while (true) {
			System.out.println("------operations are:----");
			System.out.println("enter 1 for fetch");
			System.out.println("enter 2 for insert");
			System.out.println("enter 3 for update");
			System.out.println("enter 4 for delete");

			Scanner sc = new Scanner(System.in);

			System.out.println("press the no. which operation you want to perform");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				fetch();
				break;
			case 2:
				insert();
				break;
			case 3:
				update();
				break;
			case 4:
				delete();
				break;
			default:
				System.out.println("wrong input");
			}
			System.out.println();
			System.out.println("Press 0 to continue and 1 to exit");
			int q = sc.nextInt();
			if (q == 1) {
				break;
			}

		}
	}

	public static Connection getConnect() {
		Connection con = null;
		String url = "jdbc:mysql://localhost:3306/yash";

		String user = "root";
		String pass = "Prince1234!";

		try {
			// load the driver
			Class.forName("com.mysql.jdbc.Driver");

			// create connection
			con = DriverManager.getConnection(url, user, pass);
			if (con != null) {
				System.out.println("Connection is created successfully");
			}

			else {

				System.out.println("Connection is not created");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return con;

	}

	// For fetching the all students detail from db

	public static ArrayList<Students> fetch() {
		ArrayList<Students> allStud = new ArrayList<>();

		try {
			Connection con = getConnect();
			String query = "Select * from Students";
			PreparedStatement pst = con.prepareStatement(query);
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				Students s = new Students();
				s.setId(rs.getInt("id"));
				s.setFname(rs.getString("fName"));
				s.setLname(rs.getString("lName"));
				s.setDepartment(rs.getString("department"));
				allStud.add(s);

			}

			for (Students stud : allStud) {
				System.out.println(stud.toString());
			}

		}

		catch (Exception e) {
			e.printStackTrace();
		}

		return allStud;
	}

	// For Inserting the new Student in db

	public static void insert() {

		System.out.println("Enter the student detail");
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the student id");
		int id = sc.nextInt();
		sc.nextLine();
		String lName, fName, department;

		System.out.println("enter the  first name");
		fName = sc.nextLine();
		System.out.println("enter the last name");
		lName = sc.nextLine();
		System.out.println("enter the department name");
		department = sc.nextLine();

		try {

			Connection con = getConnect();
			String query = "insert into Students values(?,?,?,?)";
			PreparedStatement pst = con.prepareStatement(query);//it 
			pst.setInt(1, id);
			pst.setString(2, fName);
			pst.setString(3, lName);
			pst.setString(4, department);

			pst.executeUpdate();
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

	// for update the Student details in db

	public static void update() {

		System.out.println("Enter the student id to update the detail");
		Scanner sc = new Scanner(System.in);
		int id = sc.nextInt();
		sc.nextLine();

		System.out.println("enter the students details for update*****************");

		System.out.println("Note : User can't change the id since it is Primary Key");
		String lName, fName, department;

		System.out.println("enter the new first name for update");
		fName = sc.nextLine();
		System.out.println("enter the new last name for update");
		lName = sc.nextLine();
		System.out.println("enter the new  department name for update");
		department = sc.nextLine();

		try {

			Connection con = getConnect();
			String query = "update Students set fName =?, lName=? , department = ? where id =?";
			PreparedStatement pst = con.prepareStatement(query);

			pst.setString(1, fName);
			pst.setString(2, lName);
			pst.setString(3, department);
			pst.setInt(4, id);

			pst.executeUpdate();
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

	// for delete the record from db

	public static void delete() {
		System.out.println("Enter the student id to delete the detail");
		Scanner sc = new Scanner(System.in);
		int id = sc.nextInt();

		try {
			Connection con = getConnect();
			String query = "delete from Students where id=?";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, id);
			pst.executeUpdate();
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}
}
