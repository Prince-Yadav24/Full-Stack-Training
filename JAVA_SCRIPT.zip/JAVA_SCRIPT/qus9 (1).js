function contains13(nums) {

    if (nums.indexOf(1) >=0 || nums.indexOf(3) >=0){
       return false
    } 
    else
    {
       return true
    }
}

console.log(contains13([1, 5]));  
console.log(contains13([2, 3]));  
console.log(contains13([7, 5])); 
