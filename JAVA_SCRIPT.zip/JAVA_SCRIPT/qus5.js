function all_max(arr) 
 {
    var max = arr[0] > arr[2] ? arr[0] : arr[2];

    arr[0] = max;
    arr[1] = max;
    arr[2] = max;

    return arr;
}
console.log(all_max([22, 30, 50]));
console.log(all_max([-4, -10, 0]));
console.log(all_max([100, -10, 300]));