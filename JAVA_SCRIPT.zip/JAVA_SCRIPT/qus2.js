function first_last_1(nums)
{
  return nums[0] == 1 || nums[nums.length - 1] == 1;
}


console.log(first_last_1([1, 2, 3]));
console.log(first_last_1([1, 2, 3, 1]));
console.log(first_last_1([2,2,3]));