//cocat method
let text1 = "Hello";
let text2 = "world!";
let text3 = "Have a nice day!";
let result = text1.concat(" ", text2, " ", text3);
console.log("concat String => "+result);

//Shift method
const days=["mon","Tue","Wed"];
let d=days.shift();
console.log(d);
console.log("using shift method =>"+days);

//unshift method
days.unshift("sun");
console.log("using unshift method =>"+days);

//Splice Method
days.splice(1,0,"mon");
console.log("using splice method=>"+days);

//slice method

let r=days.slice(2);
console.log("using slice method=>"+r);

let p=days.slice(1,3);
console.log("using slice method=>"+p);

//sort method
days.sort();
console.log("sorted string => "+days);

//reverse function
days.reverse();
console.log("reverse of string is =>"+ days);

//slice method
let q=days.slice(1,3);
console.log("After using slice method=>"+q);

let a="Yash Technologies";

//usong toLowercase
let lower=a.toLowerCase()
console.log("string using toLowercase =>"+lower);

//using toUppercase
let upper=a.toUpperCase();
console.log("string using toUppercase=>"+upper);

//index of
console.log("index of s in Yash Technologies=>"+a.indexOf('s'));

//trim method

let k="      prince yadav    ";
console.log(k+"after using trim=>"+k.trim());
