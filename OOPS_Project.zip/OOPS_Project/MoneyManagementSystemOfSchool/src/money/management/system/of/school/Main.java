package money.management.system.of.school;


// Created by Prince Yadav Emp Id:-1015064

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		Teacher Sanjay=new Teacher(1,"sanjay",6000);
		Teacher Shruti=new Teacher(1,"Shruti",5000);
		Teacher Sudhanshu=new Teacher(1,"Sudhanshu",15000);
		
		List<Teacher> teacherList=new ArrayList<>();
		teacherList.add(Sanjay);
		teacherList.add(Shruti);
		teacherList.add(Sudhanshu);
		
		
		Student prince=new Student(1,"prince",4);
		Student deepa=new Student(1,"deepa",12);
		Student Bhupesh=new Student(1,"Bhupesh",10);
		
		List<Student> StudentList=new ArrayList<>();
		StudentList.add(prince);
		StudentList.add(deepa);
		StudentList.add(prince);
		
		School ghs=new School(teacherList,StudentList);
		
		
		prince.payFees(5000);
		deepa.payFees(6000);
		System.out.println("GHS has earned $"+ghs.getTotalMoneyEarned());
		
		System.out.println("---------Making SCHOOL GHS PAY SALARY----");
		Sanjay.receiveSalary(Sanjay.getSalary());
		System.out.println("GHS has spent salary to "+Sanjay.getName()+" and now has $"+ghs.getTotalMoneyEarned());
		
		Shruti.receiveSalary(Shruti.getSalary());
		System.out.println("GHS has spent salary to "+Shruti.getName()+" and now has $"+ghs.getTotalMoneyEarned());
        
		System.out.println(prince);
		System.out.println(Sanjay);
		System.out.println(Bhupesh);
	}

}
